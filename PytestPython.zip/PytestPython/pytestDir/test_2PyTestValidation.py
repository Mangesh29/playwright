#Fixtures
import pytest


def test_thirdCheck(preSetupWork):
    print("This is Third test")
